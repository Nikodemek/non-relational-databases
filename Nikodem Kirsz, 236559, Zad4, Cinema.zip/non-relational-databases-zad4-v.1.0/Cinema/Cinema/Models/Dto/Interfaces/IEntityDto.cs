﻿namespace Cinema.Models.Dto.Interfaces;

public interface IEntityDto
{
    Guid Id { get; set; }
}