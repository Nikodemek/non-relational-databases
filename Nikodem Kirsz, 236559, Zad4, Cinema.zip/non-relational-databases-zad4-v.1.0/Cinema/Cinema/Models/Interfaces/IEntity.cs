﻿using Cinema.Models.Dto.Interfaces;

namespace Cinema.Models.Interfaces;

public interface IEntity : IEntityDto
{ }