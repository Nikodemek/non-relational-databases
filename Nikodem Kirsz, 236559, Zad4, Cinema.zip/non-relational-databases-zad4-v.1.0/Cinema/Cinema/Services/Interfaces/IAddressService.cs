﻿using Cinema.Models;

namespace Cinema.Services.Interfaces;

public interface IAddressService : ICommonService<Address>
{ }