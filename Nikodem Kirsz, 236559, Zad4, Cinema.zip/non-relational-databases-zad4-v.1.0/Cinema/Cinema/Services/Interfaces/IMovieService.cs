﻿using Cinema.Models;

namespace Cinema.Services.Interfaces;

public interface IMovieService : ICommonService<Movie>
{ }