# non-relational-databases
Assignments and knowledge acquired in 'Nierelacyjne Bazy Danych' class, PŁ FTIMS 2022.
