﻿namespace Cinema.Utils;

public class Consts
{
    public const string DatabaseConnectionString =
        "Data Source=localhost,11433;" +
        "Database=Cinema;" +
        "Integrated Security=false;" +
        "User ID=sa;" +
        "Password=N!KoD3M!01KrsZ;";
}