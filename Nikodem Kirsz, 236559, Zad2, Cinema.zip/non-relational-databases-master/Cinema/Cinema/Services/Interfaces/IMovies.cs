﻿using Cinema.Models;

namespace Cinema.Services.Interfaces;

public interface IMovies : ICommonService<Movie>
{ }