﻿using Cinema.Models;

namespace Cinema.Services.Interfaces;

public interface IScreenings : ICommonService<Screening>
{ }