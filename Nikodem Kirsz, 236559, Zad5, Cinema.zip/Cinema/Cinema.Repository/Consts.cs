﻿namespace Cinema.Repository;

public static class Consts
{
    public const string CinemaName = "NBD-Cinema";
    public const string ConnectionStringArgName = "ConnectionString";
    public const string DatabaseNameArgName = "DatabaseName";
}