﻿using Cinema.Entity;

namespace Cinema.Repository.Interfaces;

public interface IOrdersRepository : ICommonsRepository<Order>
{ }