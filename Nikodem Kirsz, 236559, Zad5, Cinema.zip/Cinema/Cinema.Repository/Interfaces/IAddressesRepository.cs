﻿using Cinema.Entity;

namespace Cinema.Repository.Interfaces;

public interface IAddressesRepository : ICommonsRepository<Address>
{ }