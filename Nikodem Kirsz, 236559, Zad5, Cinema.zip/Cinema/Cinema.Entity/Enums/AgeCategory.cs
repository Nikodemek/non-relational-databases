﻿namespace Cinema.Entity.Enums;

public enum AgeCategory
{
    G = 0,
    Pg = 13,
    Nc = 17
}