﻿namespace Cinema.Entity.Enums;

public enum ClientType
{
    Default = 1,
    Silver = 2,
    Gold = 3
}