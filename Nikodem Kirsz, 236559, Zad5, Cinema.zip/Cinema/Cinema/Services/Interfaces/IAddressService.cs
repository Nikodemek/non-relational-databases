﻿using Cinema.Entity;

namespace Cinema.Services.Interfaces;

public interface IAddressService : ICommonService<Address>
{ }