﻿using Cinema.Entity;

namespace Cinema.Services.Interfaces;

public interface IMovieService : ICommonService<Movie>
{ }