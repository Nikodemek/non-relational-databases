﻿using Cinema.Models;

namespace Cinema.Services.Interfaces;

public interface IScreenings : ICommons<Screening>
{ }