﻿using Cinema.Models;

namespace Cinema.Services.Interfaces;

public interface IMovies : ICommons<Movie>
{ }