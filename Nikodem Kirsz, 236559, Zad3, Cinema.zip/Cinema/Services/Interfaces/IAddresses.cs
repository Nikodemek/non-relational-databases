﻿using Cinema.Models;

namespace Cinema.Services.Interfaces;

public interface IAddresses : ICommons<Address>
{ }