﻿namespace Cinema.Models;

public enum ClientType
{
    Default = 1,
    Silver = 2,
    Gold = 3
}