﻿using Cinema.Models;

namespace Cinema.Services.Interfaces;

public interface IMovieService : IGenericService<Movie>
{ }